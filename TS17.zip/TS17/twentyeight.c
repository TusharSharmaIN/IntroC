//Celsuis to farhenite
#include<stdio.h>
void main()
{   float f,c;
    printf("Enter temp in Centrigrate : ");
    scanf("%f",&c); 
    f=32+c*9/5;
    printf("Fahrenhite = %f",f);
}    
