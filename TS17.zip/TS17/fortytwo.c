//Power Function

#include<stdio.h>
#include<math.h>
void main()
{	int num,pwr;
	float ans;
	
	printf("Enter Number : ");
	scanf(" %d",&num);
		
	printf("\nEnter Power : ");
	scanf(" %d",&pwr);
	
	ans=pow(num,pwr);	
	
	printf("Result %f",ans);				

}	
       
    
