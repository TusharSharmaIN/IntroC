#include<stdio.h>
void main()
{	int rad;
	float vol;
	printf("Enter the radius : ");
	scanf("%d",&rad);
	vol=(4*3.14*rad*rad*rad)/3;
	printf("Volume of the raidus = %f",vol);
}
