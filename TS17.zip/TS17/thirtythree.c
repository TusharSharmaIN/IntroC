//reverse of number
#include<stdio.h>
void main()
{   int num,temp,sum=0;    
    printf("Enter a four digit num : ");
    scanf("%d",&num);
        
    temp=num%10; 
    sum=sum*10+temp;
    num=num/10;
    
    temp=num%10;
    sum=sum*10+temp;
    num=num/10;
    
    temp=num%10;
    sum=sum*10+temp;
    num=num/10;
    
    temp=num;        
    sum=sum*10+temp;
    
    printf("Number in Reverse : %d",sum);
}
    
    

