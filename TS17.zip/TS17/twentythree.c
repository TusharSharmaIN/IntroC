//Odd or Even
#include<stdio.h>
void main()
{	int num;
	printf("Enter a number : ");
	scanf("%d",&num);
	
	if(num%2==0)
		printf("Number is Even");
	else if(num<10)
		printf("Number is Odd");

}
