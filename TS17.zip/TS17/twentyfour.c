//Odd or Even

#include<stdio.h>
void main()
{	int num;
	printf("Enter age : ");
	scanf("%d",&num);
	
	if(num>=18)
		printf("Eligible");
	else if(num<10)
		printf("Not Eligible");

}
