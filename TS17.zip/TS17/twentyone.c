#include<stdio.h>
void main()
{	int num;
	printf("Enter a number : ");
	scanf("%d",&num);
	
	if(num>10)
		printf("Number is greater than 10");
	else if(num<10)
		printf("Number is samller than 10");
}
