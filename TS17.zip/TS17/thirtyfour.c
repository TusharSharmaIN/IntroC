//Absolute 
#include<stdio.h>
void main()
{	int x;
	printf("Enter Number : ");
	scanf("%d",&x);
	
	if(x<0)
		printf("Absolute value is %d",x*-1);
	else printf("Absolute value is %d",x);	
}
