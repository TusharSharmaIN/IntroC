//positive or Negative

#include<stdio.h>
void main()
{	int num;
	printf("Enter a number : ");
	scanf("%d",&num);
	
	if(num>0)
		printf("Positive");
	else if(num<0)
		printf("Not Positive");
	else if(num==0)
		printf("Neither Positive nor Negative");

}
