#include<stdio.h>
void main()
{	int rad;
	float circum;
	printf("Enter the radius : ");
	scanf("%d",&rad);
	circum=2*3.14*rad;
	printf("Circum = %f",circum);
}
