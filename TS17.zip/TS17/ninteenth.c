#include<stdio.h>
void main()
{	int b,h;
	float area;
	printf("Enter the base & height : ");
	scanf("%d %d",&b,&h);
	area=0.5*b*h;
	printf("Area = %f",area);
}
